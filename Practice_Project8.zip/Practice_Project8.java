package Demo_Pack;

public class ImplofStrings {
	public static void main(String[] args) {
	    
	    // creating a string
	    String str1 = "Hello World";
	    //converting String to StringBuffer using append() method
	    StringBuffer sbf = new StringBuffer();
	    sbf.append(str1);
	    System.out.println("String Buffer for String=Hello World:"+sbf);
	    String str2 = "How is Life?";
	    StringBuilder sbl = new StringBuilder(str2);
	    System.out.println("String Builder for String=How is Life?:"+sbl);

}
}