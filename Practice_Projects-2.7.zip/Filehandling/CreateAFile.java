package Filehandling;
import java.io.File;
import java.io.IOException;

public class CreateAFile
{
	public static void main(String[] args)
		{
			 File f = new File("C:A.txt");   
		     try {
				if (f.createNewFile())
				 {  
				            System.out.println("File " + f.getName() + " is created successfully.");  
				 } 
				 else 
				 {  
				            System.out.println("File is already exist in the directory.");  
				 }
			} catch (IOException e) {
				
				e.printStackTrace();
			}  
		     
		   
		}
	}
