package Filehandling;

import java.io.File;

public class RenameaFile {
	public static void main(String[] args) 
    { 
        
        File f = new File("C:A.txt"); 
  
        
        File rename = new File("C:V.txt"); 
  
        
        boolean flag = f.renameTo(rename); 
  
                if (flag == true) { 
            System.out.println("File is renamed successfully"); 
        } 
        
        else { 
            System.out.println("Operation Failed"); 
        } 
    }
}
