package Filehandling;

import java.io.File;

public class DeletefromaFile {
	public static void main(String[] args) {   
	    File f = new File("C:A.txt");   
	    if (f.delete()) {   
	      System.out.println(f.getName()+ " file is deleted successfully.");  
	    } else {  
	      System.out.println("Unexpected error found in deletion of the file.");  
	    }   
	  }   
}
