package Filehandling;
import java.io.FileWriter;
import java.io.IOException;

public class WriteintoaFile {
	public static void main(String[] args) {  
	      
	    try {  
	        FileWriter fwrite = new FileWriter("C:A.txt");   
	        fwrite.write("Hello World");    
	        fwrite.close();   
	        System.out.println("Content is successfully wrote to the file.");  
	    } catch (IOException e) {  
	        System.out.println("Unexpected error occurred");  
	        e.printStackTrace();  
	        }  
	    }  
}
