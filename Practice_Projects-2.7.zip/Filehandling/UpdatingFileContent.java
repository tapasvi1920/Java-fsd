package Filehandling;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class UpdatingFileContent {
	public static void main(String[] args) {
try { 
	    	
	    	File f = new File ("C:V.txt");
	    	FileWriter fw = new FileWriter(f); 
	    	fw.write("Hello this is java File Handling");
	    	fw.close();
	    	System.out.println("Content is successfully updated."); 
	    	
	} catch (IOException e) {  
	       System.out.println("Unexpected error occurred");  
	        e.printStackTrace();  
	        }  
	    }  

	    }


