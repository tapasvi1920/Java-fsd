package Filehandling;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
public class AppendContentintoaFile {
	public static void main(String[] args) {  
	      
	    try { 
	    	
	    	File f = new File ("C:V.txt");
	    	FileWriter fw = new FileWriter(f, true); 
	    	fw.write("How are You");
	    	fw.close();
	    	System.out.println("Content is successfully appended to the existing file."); 
	    	
	} catch (IOException e) {  
	       System.out.println("Unexpected error occurred");  
	        e.printStackTrace();  
	        }  
	    }  

	    }

