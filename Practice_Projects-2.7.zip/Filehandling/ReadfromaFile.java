package Filehandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadfromaFile {
	public static void main(String[] args) {  
        try {  
             
            File f = new File("C:A.txt");    
            Scanner dataReader = new Scanner(f);  
            while (dataReader.hasNextLine()) {  
                String fileData = dataReader.nextLine();  
                System.out.println(fileData);  
            }  
            dataReader.close();  
        } catch (FileNotFoundException exception) {  
            System.out.println("Unexpected error occurred!");  
            exception.printStackTrace();  
        }  
    }  
}
