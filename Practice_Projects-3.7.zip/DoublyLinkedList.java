package Multithreading; 
  
class node { 
    node prev; 
    int data; 
    node next; 
  
   
    node(int value) 
    { 
  
        prev = null; 
        data = value; 
        next = null; 
    } 
} 
  
public class DoublyLinkedList { 
  
    // Declaring an empty doubly linked list 
    static node head = null; 
    static node tail = null; 
    
    static void insertAtEnd(int data) 
    { 
        node temp = new node(data); 
        if (tail == null) { 
            head = temp; 
            tail = temp; 
        } 
        else { 
            tail.next = temp; 
            temp.prev = tail; 
            tail = temp; 
         } 
    }
    public static void traverseForward() 
    { 
        node current = head; 
        while (current != null) { 
            System.out.print(current.data + " "); 
            current = current.next; 
        } 
    } 
    public static void traverseBackward() 
    { 
        node current = tail; 
        while (current != null) { 
            System.out.print(current.data + " "); 
            current = current.prev; 
        } 
    } 
    public static void main(String[] args) 
    { 
        insertAtEnd(1); 
        insertAtEnd(2); 
        insertAtEnd(3); 
        insertAtEnd(4); 
        insertAtEnd(5); 
        traverseForward();
        traverseBackward();
        
  
}
}