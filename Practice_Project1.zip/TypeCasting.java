package Demo_Pack;

public class TypeCasting {
	
			public static void main(String[] args) {
				int a1=10;
				double b1=a1;//widening ->implicit conversion 
				System.out.println(a1);
			
				double a=10;
				int b=(int) a;  //narrowing -> explicit conversion 
				System.out.println(b);
				


}
}
