package Learn;

public class StackImpl {
	static class Stack {

		  
		  public int arr[];
		  
		  public int top;
		  
		  public int capacity;

		  
		  Stack(int size) {
		    
		    arr = new int[size];
		    capacity = size;
		    top = -1;
		  }

		 
		  public void push(int x) {
		    if (isFull()) {
		      System.out.println("Stack OverFlow");

		      
		      System.exit(1);
		    }

		   // insert element on top of stack
		    System.out.println("Inserting " + x);
		    arr[++top] = x;
		  }

		  // pop elements from top of stack
		  public int pop() {

		   
		    if (isEmpty()) {
		      System.out.println("STACK EMPTY");
		     
		      System.exit(1);
		    }

		    
		    return arr[top--];
		  }

		 
		  public int getSize() {
		    return top + 1;
		  }

		  
		  public Boolean isEmpty() {
		    return top == -1;
		  }

		  
		  public Boolean isFull() {
		    return top == capacity - 1;
		  }

		  // display elements of stack
		  public void printStack() {
		    for (int i = 0; i <= top; i++) {
		      System.out.print(arr[i] + ", ");
		    }
		  }

		  public static void main(String[] args) {
		    Stack stack = new Stack(10);

		    stack.push(1);
		    stack.push(2);
		    stack.push(3);
		    stack.push(4);
		    stack.push(5);
		    stack.push(6);

		    System.out.print("Stack: ");
		    stack.printStack();

		    // remove element from stack
		    stack.pop();
		    System.out.println("\nAfter popping out");
		    stack.printStack();

		  }
		}
}
