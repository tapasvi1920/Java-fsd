package Learn;
class Table{  
synchronized void printTable(int n){
   for(int i=1;i<=5;i++){  
     System.out.println(n*i);  
     try{  
      Thread.sleep(400);  
     }catch(Exception e){System.out.println(e);}  
   }  
  
 }  
}  
class T1 extends Thread{  
	Table t;  
	 T1 (Table t){  
this.t=t;  
}  
public void run(){  
t.printTable(5);  
} 
}
class T2 extends Thread{  
	Table t;  
	T2 (Table t){  
this.t=t;  
}  
public void run(){  
t.printTable(100);  
}  
}  

public class Synchronization{
	public static void main(String args[]){  
		Table obj = new Table();//only one object  
		 T1  t1=new  T1 (obj);  
		 T2  t2=new T2 (obj);  
		t1.start();  
		t2.start();  
		}  	
}