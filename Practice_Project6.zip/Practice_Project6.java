package Demo_Pack;
import java.util.HashMap;

public class ImplOfMaps {
  public static void main(String[] args) {

    HashMap<Integer, String> Subjects = new HashMap<>();
    Subjects.put(001,"English");
    Subjects.put(002,"Maths");
    Subjects.put(003,"Science");
    Subjects.put(004,"Social");
    Subjects.put(005,"Telugu");
    Subjects.put(006,"Hindi");
    System.out.println("HashMap: " +Subjects);

    // get() method to get value
    String value = Subjects.get(001);
    System.out.println("Value at index 1: " + value);
    System.out.println("Keys: " + Subjects.keySet());
    System.out.println("Values: " + Subjects.values());
    System.out.println("Key/Value mappings: " + Subjects.entrySet());
    Subjects.replace(2, "Abacus");
    System.out.println("HashMap using replace(): " + Subjects);
    String value1 =  Subjects.remove(2);
    System.out.println("Removed value: " + value1);

    System.out.println("Updated HashMap: " +  Subjects);
  }
}