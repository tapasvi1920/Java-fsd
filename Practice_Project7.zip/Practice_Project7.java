package Demo_Pack;
class OuterClass {
  int a = 10;

  class InnerClass {
    int b = 5;
    public int myInnerMethod() 
    {
        return (a*b);
      }
  }
}

public class ImplOfInnerClasses {
  public static void main(String[] args) {
    OuterClass myOuter = new OuterClass();
    OuterClass.InnerClass myInner = myOuter.new InnerClass();
    //Accessing inner class from outer class
    System.out.println(myInner.b + myOuter.a);
   //Accessing Outer Class From Inner Class
    System.out.println(myInner.myInnerMethod());
  }
}
