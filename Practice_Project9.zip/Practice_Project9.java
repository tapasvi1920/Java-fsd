package Demo_Pack;

public class ImplOfArrays {
	
		 public static void main(String[] args) {
		  
		   // creating an array
		   int[] tennumbers = {1,2,3,4,5,6,7,8,9,10};
		   
		   // using for loop and displaying array elements
		   
		   for(int i = 0; i < tennumbers.length; i++) {
		     System.out.println(tennumbers[i]);
		   }
		   // using for loop and performing sum of elements in an array
		   int sum=0;
		   for(int i = 0; i < tennumbers.length; i++) {
			     sum=sum+i;
			   }
		   System.out.println(sum);
		   
		 }
		}

