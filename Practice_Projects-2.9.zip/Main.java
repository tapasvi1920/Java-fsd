//When two interfaces are implemented into a class we can solve diamond problem
//multiple inheritance is when one child class is inherited from two parent classes
//This can be achieved through interfaces
//One class is implemented from two interfaces
//We cannot inherit a class from extending two parent classes in java. It is possible only through interfaces

package Learn;

	import java.util.Scanner;

	interface A{
		void sum();
	}
	interface B{
		void difference();
	}
	class Test implements A,B{  
		int a,b,c;
		public void sum() {
			
			c=a+b;
			System.out.println("Sum is:"+c);
			
		}
		public void difference(){
			
			c=b-a;
			System.out.println("Difference is:"+c);
		}
	}
		
	public class Main {
	public static void main(String[] args) {
		Test t=new Test();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter two numbers a and b:");
		t.a=sc.nextInt();
		t.b=sc.nextInt();
		t.sum();
		t.difference();
	}
	}



