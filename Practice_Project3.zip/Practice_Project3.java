package Demo_Pack;

import java.util.Scanner;

public class ImplOfMethods {
int emp_id;
String emp_name;
double emp_salary;
void display() {
	System.out.println("Employee details are:"+emp_id+"--->"+emp_name+"--->"+emp_salary);
}
static void displayCompany(String company_name) {
	System.out.println("The employee belongs to "+company_name+"XYZ company");
	
}

public static void main(String[] args) {
	ImplOfMethods obj=new ImplOfMethods();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the id value:");
	obj.emp_id=sc.nextInt();
	System.out.println("enter the name:");
	obj.emp_name=sc.next();
	System.out.println("enter the salary value:");
	obj.emp_salary=sc.nextDouble();
	obj.display();
	String company_name = "";
	displayCompany(company_name);
	
}
}
