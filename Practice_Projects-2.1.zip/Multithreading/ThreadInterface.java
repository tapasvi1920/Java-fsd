package Multithreading;


public class ThreadInterface implements Runnable
{  
		public void run(){  
		System.out.println("thread is running...");  
		}  
		public static void main(String args[]){  
			 ThreadInterface i=new  ThreadInterface();  
			Thread t1 =new Thread(i);    
			t1.start();  
			 }  
}
