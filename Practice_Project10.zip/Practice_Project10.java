package Demo_Pack;
import java.util.regex.*;

public class Regex {
	public static void main(String args[]) {
		
		Pattern p = Pattern.compile(".s");//represents single character  
		Matcher m = p.matcher("is"); //checks whether second character in is is s or not 
		boolean b1 = m.matches(); //returns t or f based on previous statement
		boolean b2=Pattern.compile(".t").matcher("at").matches(); 
		boolean b3 = Pattern.compile(".s").matcher("ams").matches();//false (more than two characters)
		boolean b4=Pattern.matches("[amn]", "abcd");//false(not a or m or n)
		boolean b5=Pattern.matches("[amn]?", "aammza");//false (a comes more than one time) 
		boolean b6=Pattern.matches("[amn]+", "aaa");//true (a comes more than one time) 
		boolean b7=Pattern.matches("[amn]*", "ammmna");//true (a or m or n may come zero or more times) 
		boolean b8=Pattern.matches("\\d", "abc");//false not digit
		boolean b9=Pattern.matches("\\d", "4443");//false (digit but comes more than once)  
	    boolean b10=Pattern.matches("\\d", "323abc");//false (digit and char)
	    System.out.println(b1+" "+b2+" "+b3+" "+b4+" "+b5+" "+b6+" "+b7+" "+b8+" "+b9+" "+b10+"\n");

		  


	}

	}



