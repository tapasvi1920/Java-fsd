package Exceptions;

public class Test 
{
	
	public static void main(String args[]){    
	  try{    
	 
	   int n1=70/30;  
	   System.out.println(n1);
	   int n2=10/0;
	   System.out.println(n2);
	   
	  }    
	
	  catch(ArithmeticException e){  
		  System.out.println("ArithmeticException => " + e.getMessage());
	}    
	//executed regardless of exception occurred or not  
	 finally {  
	System.out.println("finally block is always executed");  
	}      
	  }    
}    