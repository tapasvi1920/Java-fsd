package Demo_Pack;
import java.util.*;

public class ImplOfCollections {
	public static void main(String args[]){  
		ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
		list.add("Monday");//Adding object in arraylist  
		list.add("Tuesday");  
		list.add("Wednesday");  
		list.add("Thursday");
		list.add("friday");
		list.add("saturday");
		list.add("sunday");
		//Traversing list through Iterator  
		Iterator itr=list.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next()); 
		//adding and displayig elements through linked list
		//LinkedList<String> al=new LinkedList<String>();  
		//al.add("Apple");  
		//al.add("Mango");  
		//al.add("Papaya");  
		//al.add("Orange");  
		//Iterator<String> fruits=al.iterator();  
		//while(fruits.hasNext()){  
		//System.out.println(fruits.next()); 
		//adding and displayig elements through vector
		//Vector<String> v=new Vector<String>();  
		//v.add("Ayush");  
		//v.add("Amit");  
		//v.add("Ashish");  
		//v.add("Garima");  
		//Iterator<String> itr=v.iterator();  
		//while(itr.hasNext()){  
		//System.out.println(itr.next());
		}  
		}  

	}

