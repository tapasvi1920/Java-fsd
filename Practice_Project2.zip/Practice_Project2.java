package Demo_Pack;
public class AccessModifiers{
	private double a=10.5;//private
	protected void demo() //protected 
    {  
        System.out.println("This is protected method");  
    }  
	public void demo1()  //public
    {  
        System.out.println("The value of a is:"+a);  
    } 
	void demo2()  //default
    {  
        System.out.println("This is protected method");  
    }  
}

 class Demo {
	 public static void main(String[] args) {
	AccessModifiers am=new AccessModifiers();
	am.demo();
	am.demo1();
	am.demo2();
	 }	
	
}
