package Demo_Pack;
public class Student {
		String name;
		int id;
		
		Student(){
			System.out.println("Hello");
			}

		
		Student(String name, int id)
		{
			this.name = name;
			this.id = id;
		}

		
		Student(Student obj2)
		{
			this.name = obj2.name;
			this.id = obj2.id;
		}
	}
	class TypesOfConstructors {
		public static void main(String[] args)
		{
			Student st=new Student();
			System.out.println("Default Contructor is implemented");
			Student st1 = new Student("Tapasvi", 23);
			System.out.println("Student Name :" + st1.name
							+ " and Student Id :" + st1.id);

			System.out.println("Parameterized Constructor is implemented");

			// This would invoke the copy constructor.
			Student st2 = new Student(st1);
			
			System.out.println("Student Name :" + st2.name
							+ " and Student Id  :" + st2.id);
			System.out.println("Copy Constructor is implemented");
			
		}
	}

