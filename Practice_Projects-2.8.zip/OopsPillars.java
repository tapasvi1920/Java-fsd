package OopsConcepts;
//inheritance
class A{
	int a=10,b=20,c;
	void sum() {
		c=a+b;
		System.out.println("sum of a and b is:"+c);
	}	
}
class B extends A{
	void square() {
		c=(a*a)+(b*b);//child class can access parent class data variables
		System.out.println("sum of squares of a and b is:"+c);
	}
}
//abstraction
abstract class C{
	abstract void display();//hiding implementation details
}
class D extends C{
	void display() {
		System.out.println("Abstraction achieved");
	}
}
//encapsulation=class will have private data member,we can access it using setter and getter methods
class E{//fully encapsulated class
	private float pi;
	public float getNum() {
		return pi;
	}
	public void setNum(float pi) {
		this.pi=pi;
	}
}
//Polymorphism
class F{
	void args() {
		System.out.println("Java");
	}
	void args(int a,double b) {
		a=5;
		b=10;
		System.out.println("numbers are:"+a+","+b);
	}
	void args(char a) {
		System.out.println(+a);
	}
}
class G extends F{
	void args() {
		System.out.println("Polymorphism");
	}
}

public class OopsPillars {
public static void main(String args[]) {
	A a=new A();//object creation for classes
	B b=new B();
	D d=new D();
	E e=new E();
	F f=new F();
	F f1=new G();//upcasting
	b.sum();//child class can access parent class methods
	b.square();
	a.sum();
	System.out.println("Inheritance achieved");
	//a.square();-->parent class cannot access child class data members
	d.display();
	e.setNum(3.14f);
	System.out.println(e.getNum());
	System.out.println("Encapsulation achieved");
	f.args('D');
	f.args(3, 4.567d);
	System.out.println("compile time Polymophism achieved");
	f1.args();
	System.out.println("run time Polymophism achieved");
	
	
}
}
