package Exceptions;
class AgeValidator {

	public void ageValidation(int age) throws InvalidAgeException {
		if(age>=18) {
			System.out.println("This person has right to vote ");
		}
		else {
			
			throw new InvalidAgeException();
		}
	}
	
}
//class need to extend superclass exception 
 class InvalidAgeException extends Exception{
//toString to print the exception definition 
	public String toString() {
		return "the age is not fit for having a vote";
	}
}
public class CustomExceptions {
	public static void main(String[] args) throws InvalidAgeException {

		AgeValidator ageobj=new AgeValidator();
		ageobj.ageValidation(28);
		ageobj.ageValidation(4);
		
	}

}
